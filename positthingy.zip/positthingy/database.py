from sqlalchemy import create_engine, Column, Integer, String, MetaData, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import relationship
from decouple import config

# DATABASE_URL = config("DATABASE_URL")
# DATABASE_URL = "mssql+pyodbc://<username>:<password>@<server>/<database>?driver=ODBC+Driver+17+for+SQL+Server"
DATABASE_URL = "sqlite:///./test_database6.db"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

class MainData(Base):
    __tablename__ = 'main_data'
    id = Column(Integer, primary_key=True)
    advisor = Column(String)
    acf2 = Column(String)
    branch = Column(String)
    metric = Column(String)
    metric_id = Column(String)
    bm_acf2 = Column(String)
    abm_acf2 = Column(String)
    refresh_date = Column(DateTime)
    current_value = Column(Integer)
    previous_month = Column(Integer)
    previous_quarter = Column(Integer)
    previous_year = Column(Integer)
    lob = Column(String)
    action = Column(String)
    procedure = Column(String)
    curr_date = Column(DateTime)

# Add a new table for status data
class StatusData(Base):
    __tablename__ = 'status'
    id = Column(Integer, primary_key=True)
    status = Column(String)
    date = Column(DateTime)
    curr_date = Column(DateTime)
    acf2 = Column(String)
    user_acf2 = Column(String)
    lob = Column(String)
    metric_id = Column(String)
    
class Comment(Base):
    __tablename__ = 'comments'
    id = Column(Integer, primary_key=True)
    comment = Column(String)
    date_stamp = Column(DateTime)
    curr_date = Column(DateTime)
    acf2 = Column(String)
    user_acf2 = Column(String)
    lob = Column(String)
    metric_id = Column(String)

'''
#THIS IS A SCRIPT TO LOAD DATA INTO DATABASE USING EXCEL
import pandas as pd
DATABASE_URL = "sqlite:///./test_database.db"
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base.metadata.create_all(bind=engine)
def insert_data_from_excel(file_path, sheet_name):
    # Read the Excel file
    data_df = pd.read_excel(file_path, sheet_name=sheet_name)

    # Establish a database session
    db = SessionLocal()

    for _, row in data_df.iterrows():
        # Create a MainData object
        main_data_entry = MainData(
            advisor=row['Advisor'],
            acf2=row['ACF2'],
            branch=row['Branch'],
            metric=row['Metric'],
            refresh_date=row['Refresh Date'],
            current=int(row['Current']) if not pd.isnull(row['Current']) else None,
            previous_month=row['Previous Month'],
            previous_quarter=row['Previous Quarter'],
            previous_year=row['Previous Year'],
            action=row['Action'],
            procedure=row['Procedure'],
            status=row['Status'],
            date=row['Date'] if not pd.isnull(row['Date']) else None
        )
        db.add(main_data_entry)
        db.commit()

        # Insert comment, if present
        comment_text = row['SRM Comments']
        if pd.notnull(comment_text):
            comment_entry = Comment(
                main_data_id=main_data_entry.id,
                comment=comment_text,
                date_stamp=row['Date Stamp']
            )
            db.add(comment_entry)
            db.commit()

# Call the function with the correct file path and sheet name
file_path = '2024-03.xlsx'
sheet_name = 'Data'  # Adjust based on the actual sheet name
insert_data_from_excel(file_path, sheet_name)
'''