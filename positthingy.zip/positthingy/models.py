from pydantic import BaseModel
from datetime import datetime
from typing import List, Optional
from datetime import date

class CommentModel(BaseModel):
    id: int
    comment: str
    date_stamp: datetime
    curr_date: datetime
    date: Optional[str] = None

    class Config:
        orm_mode = True

class MainDataModel(BaseModel):
    id: int
    advisor: str
    acf2: str
    bm_acf2:str
    abm_acf2:str
    branch: str
    metric: str
    metric_id:str
    refresh_date: datetime
    curr_date: datetime
    current: int
    previous_month: int
    previous_quarter: int
    previous_year: int
    action: str
    procedure: str

    class Config:
        orm_mode = True
class StatusModel(BaseModel):
    metric_id: str
    acf2:str
    user_acf2: str
    status: str
    date: date
    curr_date: datetime
    class Config:
        orm_mode = True
class CommentCreate(BaseModel):
    main_data_id: str
    comment: str
    date_stamp: datetime

class StatusUpdate(BaseModel):
    status: str
    refresh_date: datetime
