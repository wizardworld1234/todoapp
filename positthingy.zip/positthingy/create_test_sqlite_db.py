from sqlalchemy import create_engine
from decouple import config
from database import Base

DATABASE_URL = "sqlite:///./test_database2.db"
engine = create_engine(DATABASE_URL)

# 创建数据库表
Base.metadata.create_all(bind=engine)

# Commit changes to the database
with engine.connect() as connection:
    connection.execute("COMMIT")