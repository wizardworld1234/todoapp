from typing import List
from fastapi import FastAPI, Depends, HTTPException, Request, Query
from fastapi.responses import StreamingResponse
import io
from sqlalchemy.orm import Session
from typing import List
from database import Base, SessionLocal, engine, MainData, Comment,StatusData
from models import MainDataModel, CommentCreate, StatusUpdate
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from crud import get_data_by_branch, get_comments_for_data
from sqlalchemy import func
from typing import Optional
from collections import defaultdict
from datetime import datetime
from datetime import datetime
from datetime import timedelta
import json
from sqlalchemy import or_
import pytz

Base.metadata.create_all(bind=engine)

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def convert_to_est(date):
    eastern = pytz.timezone('US/Eastern')
    return date.astimezone(eastern)

@app.get("/comments/{main_data_id}", response_class=HTMLResponse)
def read_comments(main_data_id: int, request: Request, db: Session = Depends(get_db)):
    # Fetch the main data entry to get advisor and metric
    main_data = db.query(MainData).filter(MainData.id == main_data_id).first()
    if not main_data:
        raise HTTPException(status_code=404, detail=f"Main data with ID {main_data_id} not found")
    day_after_curr_date = main_data.curr_date + timedelta(days=1)

    # Fetch comments associated with the main data ID
    comments = db.query(Comment).filter(Comment.metric_id == main_data.metric_id, Comment.acf2 == main_data.acf2,Comment.date_stamp < day_after_curr_date).all()
    comments = [
        {'date_stamp': convert_to_est(comment.date_stamp), 'comment': comment.comment}
        for comment in comments
    ]
    return templates.TemplateResponse("comments.html", {
        "request": request,
        "comments": comments,
        "main_data_id": main_data_id,
        "advisor": main_data.advisor,
        "metric": main_data.metric,
    })


@app.post("/comments/")
async def add_comment(request: Request,comment_data: CommentCreate, db: Session = Depends(get_db)):
    # credentials = request.headers.get("RStudio-Connect-Credentials")
    # user_info = json.loads(credentials)
    # acf2 = user_info.get("user")
    acf2="6666"
    
    # Verify that the referenced MainData exists
    main_data = db.query(MainData).filter(MainData.id == comment_data.main_data_id).first()
    if not main_data:
        raise HTTPException(status_code=404, detail="MainData not found")

    # Create and insert the new comment
    new_comment = Comment(
        metric_id=main_data.metric_id,
        acf2=main_data.acf2,
        user_acf2=acf2,
        comment=comment_data.comment,
        date_stamp=comment_data.date_stamp
    )
    db.add(new_comment)
    db.commit()
    db.refresh(new_comment)

    return {"message": "Comment added successfully", "comment_id": new_comment.id}


@app.post("/update-status/{main_data_id}")
async def update_status(request: Request,main_data_id: int, update_data: StatusUpdate, db: Session = Depends(get_db)):
    # credentials = request.headers.get("RStudio-Connect-Credentials")
    # user_info = json.loads(credentials)
    # acf2 = user_info.get("user")
    acf2="6666"
    
    main_data = db.query(MainData).filter(MainData.id == main_data_id).first()
    if not main_data:
        raise HTTPException(status_code=404, detail="MainData not found")
    
    status_data = db.query(StatusData).filter(StatusData.metric_id == main_data.metric_id, StatusData.acf2 == main_data.acf2).first()
    if not status_data:
        # Insert new status data
        new_status_data = StatusData(
            metric_id=main_data.metric_id,
            acf2 = main_data.acf2,
            user_acf2=acf2,
            status=update_data.status,
            date=update_data.refresh_date
        )
        db.add(new_status_data)
    else:
        # Update existing status data
        status_data.status = update_data.status
        status_data.user_acf2 = acf2
        status_data.date = update_data.refresh_date

    db.commit()
    
    return {"message": "Status updated successfully"}

@app.get("/data")
def read_data(
    request: Request,
    db: Session = Depends(get_db),
    advisor: Optional[str] = None,
    metric: Optional[str] = None,
    status: Optional[str] = None,
    curr_date: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1)
):
    # Extracting acf2 from the RStudio-Connect-Credentials header
    credentials = request.headers.get("RStudio-Connect-Credentials")
    print("credentials",credentials)
    user_info = json.loads(credentials)
    acf2 = user_info.get("user")
    print("user_info",user_info)
    # acf2="6666"
    

    # Adjusting the query to handle multiple acf2 values in bm_acf2 and abm_acf2
    query = db.query(MainData).filter(
        or_(
            MainData.bm_acf2.contains(acf2),
            MainData.abm_acf2.contains(acf2)
        )
    )
    if advisor:
        query = query.filter(MainData.advisor == advisor)
    if metric:
        query = query.filter(MainData.metric == metric)
    if curr_date:
        curr_date = datetime.strptime(curr_date, "%Y-%m-%d %H:%M:%S")
        query = query.filter(MainData.curr_date == curr_date)
    else:
        query = query.filter(MainData.curr_date == db.query(func.max(MainData.curr_date)))
    if status:
        query = query.filter(MainData.metric_id == StatusData.metric_id, MainData.acf2 == StatusData.acf2, StatusData.status == status)  

    total = query.count() 
    print("total", total)
    data = query.offset((page - 1) * page_size).limit(page_size).all()
    data_grouped_by_advisor = defaultdict(list)
    for item in data:
        data_grouped_by_advisor[item.advisor].append(item)

    # Query StatusData table for status
    status_counts = db.query(
        StatusData.status,
        func.count(StatusData.status)
    ).group_by(StatusData.status).all()

    advisor_options = db.query(MainData.advisor).filter(
        or_(
            MainData.bm_acf2.contains(acf2),
            MainData.abm_acf2.contains(acf2)
        )
    ).distinct().all()
    advisor_options = [option[0] for option in advisor_options]
    metric_options = db.query(MainData.metric).filter(
        or_(
            MainData.bm_acf2.contains(acf2),
            MainData.abm_acf2.contains(acf2)
        )
    ).distinct().all()
    metric_options = [option[0] for option in metric_options]
    status_options = db.query(StatusData.status).distinct().all()
    status_options = [option[0] for option in status_options]
    curr_date_options = db.query(MainData.curr_date).distinct().all()
    curr_date_options = [option[0] for option in curr_date_options]
    
    counts = {status: count for status, count in status_counts}
   

    for item in data:
        status_data = db.query(StatusData).filter(StatusData.metric_id == item.metric_id,StatusData.acf2 == item.acf2).first()
        row_status = status_data.status if status_data else None
        row_status_date = status_data.date if status_data else None
        
        item.status = row_status
        item.status_date = row_status_date
        
    
         
    return templates.TemplateResponse("data3.html", {
        "request": request,
        "data_grouped_by_advisor": data_grouped_by_advisor,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": (total + page_size - 1) // page_size,
        "counts": counts,
        "advisor_options": advisor_options,
        "metric_options": metric_options,
        "status_options": status_options,
        "curr_date_options": curr_date_options,
        "selected_advisor": advisor,
        "selected_metric": metric,
        "selected_status": status,
        "selected_curr_date": curr_date
    })

@app.get("/admin")
def read_data(
    request: Request,
    db: Session = Depends(get_db),
    advisor: Optional[str] = None,
    metric: Optional[str] = None,
    status: Optional[str] = None,
    branch: Optional[str] = None,
    lob: Optional[str] = None,
    curr_date: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1)
):

    query = db.query(MainData)

    if advisor:
        query = query.filter(MainData.advisor == advisor)
    if metric:
        query = query.filter(MainData.metric == metric)
    if branch:
        query = query.filter(MainData.branch == branch)
    if lob:
        query = query.filter(MainData.lob == lob)
    if curr_date:
        curr_date = datetime.strptime(curr_date, "%Y-%m-%d").date() 
        query = query.filter(func.date(MainData.curr_date) == curr_date)
    else:
        query = query.filter(MainData.curr_date == db.query(func.max(MainData.curr_date)))
    if status:
        query = query.filter(MainData.metric_id == StatusData.metric_id,MainData.acf2 == StatusData.acf2, StatusData.status == status)    

    total = query.count() 
    data = query.offset((page - 1) * page_size).limit(page_size).all()

        
    data_grouped_by_advisor = defaultdict(list)
    for item in data:
        data_grouped_by_advisor[item.advisor].append(item)

    status_counts = db.query(
        StatusData.status,
        func.count(StatusData.status)
    ).group_by(StatusData.status).all()

    advisor_options = db.query(MainData.advisor).distinct().all()
    advisor_options = [option[0] for option in advisor_options]
    metric_options = db.query(MainData.metric).distinct().all()
    metric_options = [option[0] for option in metric_options]
    status_options = db.query(StatusData.status).distinct().all()
    status_options = [option[0] for option in status_options]
    branch_options = db.query(MainData.branch).distinct().all()
    branch_options = [option[0] for option in branch_options]
    lob_options = db.query(MainData.lob).distinct().all()
    lob_options = [option[0] for option in lob_options]
    curr_date_options = db.query(func.date(MainData.curr_date)).filter(MainData.curr_date != None).distinct().all()
    curr_date_options = [option[0] for option in curr_date_options]

    counts = {status: count for status, count in status_counts}
    
   # Fetch status from StatusData table
    for item in data:
        status_data = db.query(StatusData).filter(StatusData.metric_id == item.metric_id, StatusData.acf2 == item.acf2).first()
        row_status = status_data.status if status_data else None
        row_status_date = status_data.date if status_data else None
        
        item.status = row_status
        item.status_date = row_status_date

    return templates.TemplateResponse("admin2.html", {
            "request": request,
            "data_grouped_by_advisor": data_grouped_by_advisor,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": (total + page_size - 1) // page_size,
            "counts": counts,
            "advisor_options": advisor_options,
            "metric_options": metric_options,
            "status_options": status_options,
            "branch_options": branch_options,
            "lob_options": lob_options,
            "curr_date_options": curr_date_options,
            "selected_advisor": advisor,
            "selected_metric": metric,
            "selected_status": status,
            "selected_branch": branch,
            "selected_lob": lob,
            "selected_curr_date": curr_date,
            })



@app.get("/download-data")
def download_data(
    request: Request,
    db: Session = Depends(get_db),
    advisor: Optional[str] = Query(None),
    metric: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    curr_date: Optional[str] = Query(None)
):
    # Extracting acf2 from the RStudio-Connect-Credentials header
    # credentials = request.headers.get("RStudio-Connect-Credentials")
    # user_info = json.loads(credentials)
    # acf2 = user_info.get("user")
    acf2 = "5555"

    # Adjusting the query to handle multiple acf2 values in bm_acf2 and abm_acf2
    query = db.query(MainData).filter(
        or_(
            MainData.bm_acf2.contains(acf2),
            MainData.abm_acf2.contains(acf2)
        )
    )

    if advisor:
        query = query.filter(MainData.advisor == advisor)
    if metric:
        query = query.filter(MainData.metric == metric)
    if curr_date:
        curr_date = datetime.strptime(curr_date, "%Y-%m-%d").date() 
        query = query.filter(func.date(MainData.curr_date) == curr_date)
    else:
        query = query.filter(MainData.curr_date == db.query(func.max(MainData.curr_date)))
    if status:
        query = query.filter(MainData.metric_id == StatusData.metric_id, MainData.acf2 == StatusData.acf2, StatusData.status == status)  

    data = query.all()

    stream = io.StringIO()
    stream.write("ID,Advisor,ACF2,Branch,LOB,Metric,Refresh Date,Current Value,MOM,QOQ,YOY,Action,Procedure,Process Date,Status,Status Date,BM ACF2,ABM ACF2,Comment,Comment Date\n")  # Header
    for item in data:
        status_data = db.query(StatusData).filter(StatusData.metric_id == item.metric_id, StatusData.acf2 == item.acf2).first()
        status_value = status_data.status if status_data else None
        status_date = status_data.date if status_data else None
        
        day_after_curr_date = item.curr_date + timedelta(days=1)
        comments = db.query(Comment).filter(Comment.metric_id == item.metric_id, Comment.acf2 == item.acf2,Comment.date_stamp < day_after_curr_date).all()
        if not comments:
            stream.write(f"{item.id},{item.advisor},{item.acf2},{item.branch},{item.lob},{item.metric},{item.refresh_date},{item.current_value},{item.previous_month},{item.previous_quarter},{item.previous_year},{item.action},{item.procedure},{item.curr_date},{status_value},{status_date},\"{item.bm_acf2}\",\"{item.abm_acf2}\",,\n")
        else:
            for comment in comments:
                formatted_date = comment.date_stamp.strftime("%Y-%m-%d %H:%M:%S")
                cleaned_comment = comment.comment.replace('\n', ' ').replace('\r', '')  # Replace newlines and carriage returns
                stream.write(f"{item.id},{item.advisor},{item.acf2},{item.branch},{item.lob},{item.metric},{item.refresh_date},{item.current_value},{item.previous_month},{item.previous_quarter},{item.previous_year},{item.action},{item.procedure},{item.curr_date},{status_value},{status_date},\"{item.bm_acf2}\",\"{item.abm_acf2}\",{cleaned_comment},{formatted_date}\n")

    stream.seek(0)
    
    return StreamingResponse(iter([stream.read()]), media_type="text/csv", headers={
        "Content-Disposition": "attachment; filename=data.csv"
    })

@app.get("/download-data-admin")
def download_data(
    branch: Optional[str] = Query(None),
    lob: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    advisor: Optional[str] = Query(None),
    metric: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    curr_date: Optional[str] = Query(None)
):
    query = db.query(MainData)

    if advisor:
        query = query.filter(MainData.advisor == advisor)
    if metric:
        query = query.filter(MainData.metric == metric)
    if branch:
        query = query.filter(MainData.branch == branch)
    if lob:
        query = query.filter(MainData.lob == lob)
    if curr_date:
        curr_date = datetime.strptime(curr_date, "%Y-%m-%d").date() 
        query = query.filter(func.date(MainData.curr_date) == curr_date)
    else:
        query = query.filter(MainData.curr_date == db.query(func.max(MainData.curr_date)))
    if status:
        query = query.filter(MainData.metric_id == StatusData.metric_id, MainData.acf2 == StatusData.acf2, StatusData.status == status)  

    data = query.all()

    stream = io.StringIO()
    stream.write("ID,Advisor,ACF2,Branch,LOB,Metric,Refresh Date,Current Value,MOM,QOQ,YOY,Action,Procedure,Process Date,Status,Status Date,BM ACF2,ABM ACF2,Comment,Comment Date\n")  # Header
    for item in data:
        status_data = db.query(StatusData).filter(StatusData.metric_id == item.metric_id, StatusData.acf2 == item.acf2).first()
        status_value = status_data.status if status_data else None
        status_date = status_data.date if status_data else None
        
        day_after_curr_date = item.curr_date + timedelta(days=1)
        comments = db.query(Comment).filter(Comment.metric_id == item.metric_id, Comment.acf2 == item.acf2,Comment.date_stamp < day_after_curr_date).all()
        if not comments:
            stream.write(f"{item.id},{item.advisor},{item.acf2},{item.branch},{item.lob},{item.metric},{item.refresh_date},{item.current_value},{item.previous_month},{item.previous_quarter},{item.previous_year},{item.action},{item.procedure},{item.curr_date},{status_value},{status_date},\"{item.bm_acf2}\",\"{item.abm_acf2}\",,\n")
        else:
            for comment in comments:
                formatted_date = comment.date_stamp.strftime("%Y-%m-%d %H:%M:%S")
                cleaned_comment = comment.comment.replace('\n', ' ').replace('\r', '')  # Replace newlines and carriage returns
                stream.write(f"{item.id},{item.advisor},{item.acf2},{item.branch},{item.lob},{item.metric},{item.refresh_date},{item.current_value},{item.previous_month},{item.previous_quarter},{item.previous_year},{item.action},{item.procedure},{item.curr_date},{status_value},{status_date},\"{item.bm_acf2}\",\"{item.abm_acf2}\",{cleaned_comment},{formatted_date}\n")

    stream.seek(0)

    return StreamingResponse(iter([stream.read()]), media_type="text/csv", headers={
        "Content-Disposition": f"attachment; filename=data.csv"
    })