运行说明：

1) 安装依赖

pip install -r requirements.txt

2) 启动应用

python app.py

3) 浏览器访问

http://127.0.0.1:5000


