from flask import Flask, render_template, request, jsonify, send_file
import sqlite3
from datetime import datetime
import pandas as pd
from io import BytesIO

app = Flask(__name__)

def get_db_connection():
    """Get database connection"""
    conn = sqlite3.connect('fcra_data.db')
    conn.row_factory = sqlite3.Row
    return conn

def _parse_process_date(date_str: str) -> datetime | None:
    """Parse date string from CSV/DB (YYYY/M/D or YYYY/MM/DD) to datetime."""
    if not date_str:
        return None
    try:
        parts = date_str.split('/')
        if len(parts) == 3:
            y = int(parts[0])
            m = int(parts[1])
            d = int(parts[2])
            return datetime(y, m, d)
        return None
    except Exception:
        return None

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@app.route('/api/summary_stats')
def get_summary_stats():
    """Get statistics for Summary page"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Total instances
    cursor.execute('''
        SELECT portfolio, COUNT(*) as count 
        FROM fcra_records 
        GROUP BY portfolio
    ''')
    instances = cursor.fetchall()
    instances_dict = {row['portfolio']: row['count'] for row in instances}
    
    # Exception count (all non-Nonexceptions counted, including Resolved)
    cursor.execute('''
        SELECT portfolio, COUNT(*) as count
        FROM fcra_records
        WHERE remediation_status <> 'Nonexceptions'
        GROUP BY portfolio
    ''')
    exceptions = cursor.fetchall()
    exceptions_dict = {row['portfolio']: row['count'] for row in exceptions}
    
    # Remediation incomplete (Incomplete status)
    cursor.execute('''
        SELECT portfolio, COUNT(*) as count 
        FROM fcra_records 
        WHERE remediation_status = 'Incomplete'
        GROUP BY portfolio
    ''')
    remediation_incomplete = cursor.fetchall()
    remediation_incomplete_dict = {row['portfolio']: row['count'] for row in remediation_incomplete}
    
    # Count Incomplete by remediation_category (for second red card)
    cursor.execute('''
        SELECT remediation_category, COUNT(*) as count
        FROM fcra_records
        WHERE remediation_status = 'Incomplete'
        AND remediation_category != ''
        GROUP BY remediation_category
    ''')
    category_incomplete = cursor.fetchall()
    category_dict = {row['remediation_category']: row['count'] for row in category_incomplete}
    category_total = sum(category_dict.values())
    
    # LOB engagement by portfolio (for chart's fourth dimension)
    cursor.execute('''
        SELECT portfolio, COUNT(*) as count
        FROM fcra_records
        WHERE remediation_status = 'Incomplete' AND remediation_category = 'LOB engagement'
        GROUP BY portfolio
    ''')
    lob_rows = cursor.fetchall()
    lob_by_portfolio = {row['portfolio']: row['count'] for row in lob_rows}

    conn.close()
    
    portfolios = ['Credit Cards', 'TDAF', 'Consumers']
    
    return jsonify({
        'instances': {
            'total': sum(instances_dict.get(p, 0) for p in portfolios),
            'Credit Cards': instances_dict.get('Credit Cards', 0),
            'TDAF': instances_dict.get('TDAF', 0),
            'Consumer': instances_dict.get('Consumers', 0)
        },
        'exceptions': {
            'total': sum(exceptions_dict.get(p, 0) for p in portfolios),
            'Credit Cards': exceptions_dict.get('Credit Cards', 0),
            'TDAF': exceptions_dict.get('TDAF', 0),
            'Consumer': exceptions_dict.get('Consumers', 0)
        },
        'remediation_incomplete': {
            'total': sum(remediation_incomplete_dict.get(p, 0) for p in portfolios),
            'Credit Cards': remediation_incomplete_dict.get('Credit Cards', 0),
            'TDAF': remediation_incomplete_dict.get('TDAF', 0),
            'Consumer': remediation_incomplete_dict.get('Consumers', 0)
        },
        # For frontend compatibility, lob_incomplete.total equals sum of Incomplete by category
        'lob_incomplete': {
            'total': category_total
        },
        'lob_incomplete_by_portfolio': {
            'Credit Cards': lob_by_portfolio.get('Credit Cards', 0),
            'TDAF': lob_by_portfolio.get('TDAF', 0),
            'Consumer': lob_by_portfolio.get('Consumers', 0)
        },
        'category_incomplete': {
            'Internal': category_dict.get('Internal', 0),
            'LOB engagement': category_dict.get('LOB engagement', 0),
            'Technology': category_dict.get('Technology', 0)
        }
    })

@app.route('/api/summary_table')
def get_summary_table():
    """Get table data for Summary page"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Summary (Overall)
    cursor.execute('''
        SELECT COUNT(*) as instances,
               SUM(CASE WHEN remediation_status <> 'Nonexceptions' THEN 1 ELSE 0 END) as exceptions,
               SUM(CASE WHEN remediation_status = 'Incomplete' THEN 1 ELSE 0 END) as remediation_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'LOB engagement' THEN 1 ELSE 0 END) as lob_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Internal' THEN 1 ELSE 0 END) as internal_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Technology' THEN 1 ELSE 0 END) as technology_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND CAST(aging AS INTEGER) >= 90 THEN 1 ELSE 0 END) as ninety_days_incomplete
        FROM fcra_records
    ''')
    total_row = cursor.fetchone()

    # Group details
    cursor.execute('''
        SELECT portfolio, 
               COUNT(*) as instances,
               SUM(CASE WHEN remediation_status <> 'Nonexceptions' THEN 1 ELSE 0 END) as exceptions,
               SUM(CASE WHEN remediation_status = 'Incomplete' THEN 1 ELSE 0 END) as remediation_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'LOB engagement' THEN 1 ELSE 0 END) as lob_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Internal' THEN 1 ELSE 0 END) as internal_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Technology' THEN 1 ELSE 0 END) as technology_incomplete,
               SUM(CASE WHEN remediation_status = 'Incomplete' AND CAST(aging AS INTEGER) >= 90 THEN 1 ELSE 0 END) as ninety_days_incomplete
        FROM fcra_records
        GROUP BY portfolio
    ''')
    rows = cursor.fetchall()
    conn.close()
    
    data = []
    # Add Overall row first
    data.append({
        'portfolio': 'Overall',
        'instances': total_row['instances'],
        'exceptions': total_row['exceptions'],
        'remediation_incomplete': total_row['remediation_incomplete'],
        'lob_incomplete': total_row['lob_incomplete'],
        'internal_incomplete': total_row['internal_incomplete'],
        'technology_incomplete': total_row['technology_incomplete'],
        'ninety_days_incomplete': total_row['ninety_days_incomplete']
    })
    
    for row in rows:
        portfolio = row['portfolio']
        if portfolio == 'Consumers':
            portfolio = 'Consumer'
        data.append({
            'portfolio': portfolio,
            'instances': row['instances'],
            'exceptions': row['exceptions'],
            'remediation_incomplete': row['remediation_incomplete'],
            'lob_incomplete': row['lob_incomplete'],
            'internal_incomplete': row['internal_incomplete'],
            'technology_incomplete': row['technology_incomplete'],
            'ninety_days_incomplete': row['ninety_days_incomplete']
        })
    
    return jsonify(data)

@app.route('/api/as_of_date')
def get_as_of_date():
    """Return the latest process_date from database (maximum date)."""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT process_date FROM fcra_records WHERE process_date != ""')
    rows = cursor.fetchall()
    conn.close()

    latest: datetime | None = None
    for row in rows:
        dt = _parse_process_date(row['process_date'])
        if dt and (latest is None or dt > latest):
            latest = dt

    if latest is None:
        return jsonify({'as_of': ''})

    return jsonify({'as_of': latest.strftime('%Y-%m-%d')})

def _parse_month(date_str: str) -> str | None:
    """Convert 'YYYY/M/D' to 'YYYY-MM' month string."""
    try:
        parts = date_str.split('/')
        if len(parts) != 3:
            return None
        y = int(parts[0])
        m = int(parts[1])
        return f"{y:04d}-{m:02d}"
    except Exception:
        return None

@app.route('/api/trend')
def get_trend():
    """Aggregate trend data by month based on Date of Info.

    Parameter metric:
      - instances: all records count
      - exceptions: remediation_status <> 'Nonexceptions'
      - remediation: remediation_status = 'Incomplete'
      - lob: remediation_status = 'Incomplete' AND remediation_category = 'LOB engagement'
    Returns: { labels: [YYYY-MM...], series: { 'Credit Cards': [...], 'TDAF': [...], 'Consumer': [...] } }
    """
    metric = request.args.get('metric', 'instances')
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT portfolio, date_of_info, remediation_status, remediation_category
        FROM fcra_records
        WHERE date_of_info != ''
    ''')
    rows = cursor.fetchall()
    conn.close()

    # Collect months
    months_set = set()
    records = []
    for r in rows:
        month = _parse_month(r['date_of_info'])
        if not month:
            continue
        months_set.add(month)
        records.append({
            'portfolio': r['portfolio'],
            'month': month,
            'status': r['remediation_status'],
            'category': r['remediation_category'] or ''
        })

    labels = sorted(months_set)
    portfolios = ['Credit Cards', 'TDAF', 'Consumers']
    series = { 'Credit Cards': [0]*len(labels), 'TDAF': [0]*len(labels), 'Consumer': [0]*len(labels) }

    idx = {m:i for i,m in enumerate(labels)}
    for rec in records:
        p = rec['portfolio']
        # Map Consumers -> Consumer
        key = 'Consumer' if p == 'Consumers' else p
        if key not in series:
            continue
        i = idx[rec['month']]
        if metric == 'instances':
            series[key][i] += 1
        elif metric == 'exceptions':
            if rec['status'] != 'Nonexceptions':
                series[key][i] += 1
        elif metric == 'remediation':
            if rec['status'] == 'Incomplete':
                series[key][i] += 1
        elif metric == 'lob':
            if rec['status'] == 'Incomplete' and rec['category'] == 'LOB engagement':
                series[key][i] += 1

    return jsonify({ 'labels': labels, 'series': series })

@app.route('/api/portfolio_stats/<portfolio>')
def get_portfolio_stats(portfolio):
    """Get statistics for specific portfolio"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Adjust portfolio name to match database
    db_portfolio = 'Consumers' if portfolio == 'Consumer' else portfolio
    
    # Total instances
    cursor.execute('''
        SELECT COUNT(*) as count 
        FROM fcra_records 
        WHERE portfolio = ?
    ''', (db_portfolio,))
    total_instances = cursor.fetchone()['count']
    
    # Exception count (all non-Nonexceptions counted)
    cursor.execute('''
        SELECT COUNT(*) as count 
        FROM fcra_records 
        WHERE portfolio = ? AND remediation_status <> 'Nonexceptions'
    ''', (db_portfolio,))
    total_exceptions = cursor.fetchone()['count']
    
    # Total remediation incomplete (only Incomplete)
    cursor.execute('''
        SELECT COUNT(*) as count 
        FROM fcra_records 
        WHERE portfolio = ? AND remediation_status = 'Incomplete'
    ''', (db_portfolio,))
    remediation_incomplete = cursor.fetchone()['count']
    
    # Count Incomplete by remediation_category
    cursor.execute('''
        SELECT remediation_category, COUNT(*) as count 
        FROM fcra_records 
        WHERE portfolio = ? 
        AND remediation_status = 'Incomplete'
        AND remediation_category != ''
        GROUP BY remediation_category
    ''', (db_portfolio,))
    category_stats = cursor.fetchall()
    category_dict = {row['remediation_category']: row['count'] for row in category_stats}

    # Count by remediation_status (for second card dimension display)
    cursor.execute('''
        SELECT remediation_status, COUNT(*) as count
        FROM fcra_records
        WHERE portfolio = ?
        GROUP BY remediation_status
    ''', (db_portfolio,))
    status_rows = cursor.fetchall()
    status_counts = {row['remediation_status']: row['count'] for row in status_rows}
    
    conn.close()
    
    return jsonify({
        'total_instances': total_instances,
        'total_exceptions': total_exceptions,
        'remediation_incomplete': remediation_incomplete,
        'category_incomplete': {
            'Internal': category_dict.get('Internal', 0),
            'LOB engagement': category_dict.get('LOB engagement', 0),
            'Technology': category_dict.get('Technology', 0)
        },
        'status_counts': {
            'Resolved': status_counts.get('Resolved', 0),
            'Incomplete': status_counts.get('Incomplete', 0),
            'Unsolved': status_counts.get('Unsolved', 0),
            'Nonexceptions': status_counts.get('Nonexceptions', 0)
        }
    })

@app.route('/api/portfolio_data/<portfolio>')
def get_portfolio_data(portfolio):
    """Get table data for specific portfolio"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Adjust portfolio name to match database
    db_portfolio = 'Consumers' if portfolio == 'Consumer' else portfolio
    
    # Get filter parameters
    remediation_status = request.args.get('remediation_status', '')
    remediation_category = request.args.get('remediation_category', '')
    
    query = '''
        SELECT * FROM fcra_records 
        WHERE portfolio = ?
    '''
    params = [db_portfolio]
    
    if remediation_status:
        query += ' AND remediation_status = ?'
        params.append(remediation_status)
    
    if remediation_category:
        query += ' AND remediation_category = ?'
        params.append(remediation_category)
    
    query += ' ORDER BY id'
    
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    
    data = []
    for row in rows:
        data.append({
            'id': row['id'],
            'acct_number': row['acct_number'],
            'portfolio': row['portfolio'],
            'rule_id': row['rule_id'],
            'rule_category': row['rule_category'],
            'severity': row['severity'],
            'dqs_status': row['dqs_status'],
            'date_of_info': row['date_of_info'],
            'aging': row['aging'],
            'process_date': row['process_date'],
            'remediation_status': row['remediation_status'],
            'action_taken_by': row['action_taken_by'] or '',
            'action_notes': row['action_notes'] or '',
            'action_date': row['action_date'] or '',
            'assigned_to': row['assigned_to'] or '',
            'remediation_category': row['remediation_category'] or ''
        })
    
    return jsonify(data)


@app.route('/api/filter_options/<portfolio>')
def get_filter_options(portfolio):
    """Get filter options"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    db_portfolio = 'Consumers' if portfolio == 'Consumer' else portfolio
    
    # Get Remediation Status options
    cursor.execute('''
        SELECT DISTINCT remediation_status 
        FROM fcra_records 
        WHERE portfolio = ? AND remediation_status != ''
        ORDER BY remediation_status
    ''', (db_portfolio,))
    remediation_statuses = [row['remediation_status'] for row in cursor.fetchall()]
    
    # Get Remediation Category options
    cursor.execute('''
        SELECT DISTINCT remediation_category 
        FROM fcra_records 
        WHERE portfolio = ? AND remediation_category != ''
        ORDER BY remediation_category
    ''', (db_portfolio,))
    remediation_categories = [row['remediation_category'] for row in cursor.fetchall()]
    
    conn.close()
    
    return jsonify({
        'remediation_statuses': remediation_statuses,
        'remediation_categories': remediation_categories
    })

@app.route('/api/get_incomplete_count/<assignee>')
def get_incomplete_count(assignee):
    """Get incomplete task count for a person"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT COUNT(*) as count 
        FROM fcra_records 
        WHERE assigned_to = ? AND remediation_status IN ('Incomplete', 'Unsolved')
    ''', (assignee,))
    
    count = cursor.fetchone()['count']
    conn.close()
    
    return jsonify({'count': count})

@app.route('/api/export/<portfolio>')
def export_data(portfolio):
    """Export data to Excel"""
    conn = get_db_connection()
    
    if portfolio == 'summary':
        # Export Summary table data (including Overall)
        total_q = '''
            SELECT 'Overall' as portfolio,
                   COUNT(*) as instances,
                   SUM(CASE WHEN remediation_status <> 'Nonexceptions' THEN 1 ELSE 0 END) as exceptions,
                   SUM(CASE WHEN remediation_status = 'Incomplete' THEN 1 ELSE 0 END) as remediation_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'LOB engagement' THEN 1 ELSE 0 END) as lob_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Internal' THEN 1 ELSE 0 END) as internal_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Technology' THEN 1 ELSE 0 END) as technology_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND CAST(aging AS INTEGER) >= 90 THEN 1 ELSE 0 END) as ninety_days_incomplete
            FROM fcra_records
        '''
        detail_q = '''
            SELECT CASE WHEN portfolio = 'Consumers' THEN 'Consumer' ELSE portfolio END as portfolio,
                   COUNT(*) as instances,
                   SUM(CASE WHEN remediation_status <> 'Nonexceptions' THEN 1 ELSE 0 END) as exceptions,
                   SUM(CASE WHEN remediation_status = 'Incomplete' THEN 1 ELSE 0 END) as remediation_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'LOB engagement' THEN 1 ELSE 0 END) as lob_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Internal' THEN 1 ELSE 0 END) as internal_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND remediation_category = 'Technology' THEN 1 ELSE 0 END) as technology_incomplete,
                   SUM(CASE WHEN remediation_status = 'Incomplete' AND CAST(aging AS INTEGER) >= 90 THEN 1 ELSE 0 END) as ninety_days_incomplete
            FROM fcra_records
            GROUP BY portfolio
        '''
        import pandas as _pd
        df_total = _pd.read_sql_query(total_q, conn)
        df_detail = _pd.read_sql_query(detail_q, conn)
        df = _pd.concat([df_total, df_detail], ignore_index=True)
    else:
        # Export Portfolio data
        db_portfolio = 'Consumers' if portfolio == 'Consumer' else portfolio
        query = '''
            SELECT acct_number, portfolio, rule_id, rule_category, severity,
                   dqs_status, date_of_info, aging, process_date, remediation_status,
                   action_taken_by, action_notes, action_date, assigned_to, remediation_category
            FROM fcra_records 
            WHERE portfolio = ?
        '''
        df = pd.read_sql_query(query, conn, params=(db_portfolio,))
    
    conn.close()
    
    # Create Excel file
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Data')
    output.seek(0)
    
    return send_file(
        output,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'{portfolio}_export.xlsx'
    )

@app.route('/api/record/<int:record_id>')
def get_record(record_id):
    """Get single record details"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT * FROM fcra_records WHERE id = ?
    ''', (record_id,))
    
    record = cursor.fetchone()
    conn.close()
    
    if record:
        return jsonify(dict(record))
    else:
        return jsonify({'error': 'Record not found'}), 404

@app.route('/api/record/<int:record_id>', methods=['PUT'])
def update_record(record_id):
    """Update single record and save history"""
    data = request.json
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get old record first
    cursor.execute('SELECT * FROM fcra_records WHERE id = ?', (record_id,))
    old_record = cursor.fetchone()
    
    if not old_record:
        conn.close()
        return jsonify({'error': 'Record not found'}), 404
    
    # Prepare new values
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    new_action_date = data.get('action_date', current_time.split()[0])
    new_remediation_status = data.get('remediation_status', old_record['remediation_status'])
    new_action_taken_by = data.get('action_taken_by', old_record['action_taken_by'])
    new_action_notes = data.get('action_notes', old_record['action_notes'])
    new_assigned_to = data.get('assigned_to', old_record['assigned_to'])
    new_remediation_category = data.get('remediation_category', old_record['remediation_category'])
    
    # Update record first
    cursor.execute('''
        UPDATE fcra_records 
        SET remediation_status = ?,
            action_taken_by = ?,
            action_notes = ?,
            assigned_to = ?,
            remediation_category = ?,
            action_date = ?
        WHERE id = ?
    ''', (
        new_remediation_status,
        new_action_taken_by,
        new_action_notes,
        new_assigned_to,
        new_remediation_category,
        new_action_date,
        record_id
    ))
    
    # Save the NEW values to history (after change)
    cursor.execute('''
        INSERT INTO fcra_history (
            record_id, remediation_status, action_taken_by, action_notes,
            assigned_to, remediation_category, action_date, changed_by, changed_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        record_id,
        new_remediation_status,
        new_action_taken_by,
        new_action_notes,
        new_assigned_to,
        new_remediation_category,
        new_action_date,
        data.get('changed_by', 'Current User'),
        current_time
    ))
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/record/<int:record_id>/history')
def get_record_history(record_id):
    """Get history of changes for a single record"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT * FROM fcra_history 
        WHERE record_id = ?
        ORDER BY changed_at DESC
    ''', (record_id,))
    
    history = cursor.fetchall()
    conn.close()
    
    return jsonify([dict(row) for row in history])

if __name__ == '__main__':
    app.run(debug=True, port=5000)

